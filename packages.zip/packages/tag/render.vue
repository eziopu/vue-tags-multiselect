<script>
import { defineComponent } from "vue";
export default defineComponent({
  name: "tagRender",
  props: ["elm", "elmClass"],
  render(createElement) {
    const shell = {
      class: this.elmClass,
    };

    return createElement("div", shell, this.elm);
  },
});
</script>
