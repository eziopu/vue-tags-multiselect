export default {
  methods: {
    slotsToText(slots) {
      let result = "";
      slots.forEach((slot) => {
        result += this.slotToText(slot);
      });
      return result;
    },
    slotToText(slot) {
      let result = "";
      if (slot.children && slot.children.length != 0) {
        slot.children.forEach((slot) => {
          result += this.slotToText(slot);
        });
      }
      return result + (slot.text ? " " + slot.text : "");
    },
  },
};
